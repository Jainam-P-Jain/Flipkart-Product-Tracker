import React from "react";
import './Home.css'; // Import custom CSS
import { Link } from 'react-router-dom';
import Products from "../Products/Products";

const HomePage = () => {
  // Static product data
  const products = [
    {
      id: 1,
      title: "Smartphone XYZ jbehfhiSVGRRRRRRRRRRRRRRRRRRRRRRRRRRRRR",
      price: "₹15,999",
      rating: 4.5,
      image: "https://inspireonline.in/cdn/shop/files/iPhone_15_Pro_Max_Natural_Titanium_PDP_Image_Position-1__en-IN_579f81d6-76fb-499c-acd8-5291290f4b22.jpg?v=1694758946", // Replace with actual product images
    },
    {
      id: 2,
      title: "Laptop ABC",
      price: "₹45,999",
      rating: 4.8,
      image: "https://images.samsung.com/is/image/samsung/p6pim/in/ua43t5450akxxl/gallery/in-fhd-t5310-428860-ua43t5450akxxl-532972981?$650_519_PNG$",
    },
    {
      id: 3,
      title: "Smartwatch DEF",
      price: "₹4,999",
      rating: 4.2,
      image: "https://images.samsung.com/is/image/samsung/p6pim/in/ua43t5450akxxl/gallery/in-fhd-t5310-428860-ua43t5450akxxl-532972981?$650_519_PNG$",
    },
    {
      id: 4,
      title: "Headphones GHI",
      price: "₹1,999",
      rating: 4.3,
      image: "https://images.samsung.com/is/image/samsung/p6pim/in/ua43t5450akxxl/gallery/in-fhd-t5310-428860-ua43t5450akxxl-532972981?$650_519_PNG$",
    },
  ];

  return (
    <div className="container my-5">
      <div className="text-center mb-5">
        <h1 className="display-4 font-weight-bold">Welcome to Our Site!</h1>
        <p className="lead">
          Discover amazing deals on the best products curated just for you.
        </p>
      </div>
      
      <h2 className="text-center mb-4">Our Recent Products</h2>
      <div className="row">
        {products.map((product) => (
          <Products key={product.id} product={product} />
        ))}
      </div>

      <h2 className="text-center mb-4">Most Viwed Products</h2>
      <div className="row">
        {products.map((product) => (
          <Products key={product.id} product={product} />
        ))}
      </div>

      <h2 className="text-center mb-4">Most Rated Products</h2>
      <div className="row">
        {products.map((product) => (
          <Products key={product.id} product={product} />
        ))}
      </div>
    </div>

  );
};

export default HomePage;
