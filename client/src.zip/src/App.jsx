import { useState } from 'react'
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ProductFetcher from './components/ProductFetcher/ProductFetcher'
import HomePage from './components/Home/Home';
import Navbar from './components/Navbar/Navbar'

function App() {
  const [count, setCount] = useState(0)

  return (
    <Router>
      <div className="App">
        <Navbar /> {/* Include your Navbar */}
        <Routes>
        <Route path="/" element={<HomePage />} /> {/* Home Page */}
          <Route path="/search" element={<ProductFetcher />} /> {/* Example Product Page */}
        </Routes>
      </div>
    </Router>
  );
}

export default App
