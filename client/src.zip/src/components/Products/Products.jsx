import React from 'react';
import { Link } from 'react-router-dom';
import './Products.css'; // Ensure you import your CSS

const truncateTitle = (title, maxLength) => {
    return title.length > maxLength ? `${title.substring(0, maxLength)}...` : title;
  };

const Products = ({ product }) => {
  const truncatedTitle = truncateTitle(product.title, 20)
  return (
    <div className="col-md-3 mb-4">
      <Link to={`/product/${product.id}`} className="text-decoration-none">
        <div className="card shadow-sm">
          <img
            src={product.image}
            className="card-img-top product-img"
            alt={product.title}
          />
          <div className="card-body">
            <h5 className="card-title">{truncatedTitle}</h5>
            <p className="card-text">
              <strong>Price:</strong> {product.price}
            </p>
            <p className="card-text">
              <strong>Rating:</strong> {product.rating} ⭐
            </p>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default Products;